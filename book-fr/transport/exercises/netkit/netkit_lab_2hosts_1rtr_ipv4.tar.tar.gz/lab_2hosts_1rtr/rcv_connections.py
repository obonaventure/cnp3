#!/usr/bin/env python
# encoding: utf-8
"""
untitled.py

Created by Virginie Van den Schrieck on 2010-10-18.
Contact : 
Copyright (c) 2010 . All rights reserved.
"""

import sys, socket
from optparse import OptionParser

DEFAULT_ARGS=True


###############################################################################

def main():
    """Main function
       Called only when script is run directly. Manage script arguments"""

    usage = "usage: %prog [options] <# connections> <IP sender>"

    parser = OptionParser(usage=usage)
                  
    (options, args) = parser.parse_args()
    if DEFAULT_ARGS and len(args)==0 : 
        args=[]
        # Append default arguments to args
        args.append("1")
        args.append("10.0.2.2")
        
        
    #Check arg number
    if not len(args)== 2: 
       parser.print_help()
       sys.exit(0)
    # Call function run to make the real job
    run(args)

###############################################################################

def run(args) :
    """Real job is done here""" 
    HOST=args[1]
    PORT=12345  
    s = None
    for res in socket.getaddrinfo(HOST, PORT, socket.AF_INET    ,
                                  socket.SOCK_STREAM):
        af, socktype, proto, canonname, sa = res
        try:
            s = socket.socket(af, socktype, proto)
        except socket.error, msg:
            s = None
            continue
        try:
            s.bind(sa)
            s.listen(1)
        except socket.error, msg:
            s.close()
            s = None
            continue
        break
    if s is None:
        print 'could not open socket'
        sys.exit(1)
    while(1) : 
        conn, addr = s.accept()
        print 'Connected by', addr
        data = conn.recv(1024)
        print "received", data

    #conn.close()



###############################################################################
# Script executed directly : call main


if __name__ == "__main__":
    sys.exit(main())
