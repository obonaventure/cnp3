#!/usr/bin/env python
# encoding: utf-8
"""
untitled.py

Created by Virginie Van den Schrieck on 2010-10-18.
Contact : 
Copyright (c) 2010 . All rights reserved.
"""

import sys, socket
from optparse import OptionParser

DEFAULT_ARGS=True


###############################################################################

def main():
    """Main function
       Called only when script is run directly. Manage script arguments"""

    usage = "usage: %prog [options] <# connections> <IP receiver>"

    parser = OptionParser(usage=usage)
                  
    (options, args) = parser.parse_args()
    if DEFAULT_ARGS and len(args)==0 : 
        args=[]
        # Append default arguments to args
        args.append("1")
        args.append("10.0.2.2")
        
        
    #Check arg number
    if not len(args)== 2: 
       parser.print_help()
       sys.exit(0)
    # Call function run to make the real job
    run(args)

###############################################################################

def run(args) :
    """Real job is done here""" 
    HOST=args[1]
    PORT=12345
    s = [None, None, None, None, None]
    for i in range(5) : 
        for res in socket.getaddrinfo(HOST, PORT, socket.AF_INET, socket.SOCK_STREAM):
            af, socktype, proto, canonname, sa = res
            try:
                s[i] = socket.socket(af, socktype, proto)
            except socket.error, msg:
                s[i] = None
                continue
            try:
                s[i].connect(sa)
            except socket.error, msg:
                s[i].close()
                s[i] = None
                continue
            break
        if s is None:
            print 'could not open socket'+str(i)
            sys.exit(1)
    print s
    for i in range(5) : 
        s[i].send('Hello, world from'+str(i))
        # data = s[i].recv(1024)
        #s[i].shutdown(socket.SHUT_RDWR)




###############################################################################
# Script executed directly : call main


if __name__ == "__main__":
    sys.exit(main())
